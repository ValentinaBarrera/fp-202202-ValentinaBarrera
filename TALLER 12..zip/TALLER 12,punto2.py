#El programa solicita lado y dibujar un triangulo con *

valorlado = int(input("Ingresar el lado del triangulo: "))
valorlado2 = int(input("Ingresar el lado del triangulo: "))

for i in range(valorlado):
    print()
    for i in range(valorlado2):
        print("*",end="")


