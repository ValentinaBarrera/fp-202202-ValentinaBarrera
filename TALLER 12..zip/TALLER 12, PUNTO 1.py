#El programa solicita base y altura y dibujar un rectangulo con *
valorbase = int(input("Ingresar base del rectangulo: "))
valoraltura = int(input("Ingresar altura del rectangulo: "))

for i in range(valoraltura):
    print()
    for i in range(valorbase):
        print("*",end="")


